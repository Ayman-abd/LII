# Projet 5A ONERA — Inversion bayésienne TiRe-LII (taille des suies)

Encadrant : Romain Ceolato (ONERA Toulouse). Volet PINN demandé en exploration.

## 1. Le problème en bref
- Un laser (ns) chauffe des billes de suie (monomères 10–50 nm) jusqu'à ~3500 K ; elles refroidissent
  par conduction vers le gaz en ~1 µs. On mesure leur incandescence S(t).
- Petite bille = refroidissement rapide (chaleur stockée ∝ d³, perdue ∝ d²  =>  vitesse ∝ 1/d).
- Les tailles suivent une log-normale (d_pg = médiane, σ_g = largeur) : **les 2 seules inconnues**.
- Modèle direct (« modèle LII basse fluence, conduction en régime moléculaire libre », Michelsen 2007) :
  `m cp dT/dt = Q_abs(t) − Q_cond(T) − Q_rad(T)`, sans sublimation ;
  signal = ∫ p(d; d_pg, σ_g) · d³ · Planck(λ_det, T(t,d)) dd.
- Problème mal posé : des distributions de même diamètre de Sauter
  `d32 = d_pg·exp(2.5 ln²σ_g)` donnent des signaux quasi identiques -> vallée dans le plan (d_pg, σ_g).
- Couplage α–d : en conduction pure, seul α/d compte (Sipkens 2015, Daun 2007) -> une erreur
  sur α biaise d proportionnellement.

## 2. Ce qui est fait
| Fichier | Contenu | Validation |
|---|---|---|
| `lii_model.py` | EDO monodisperse (absorption gaussienne, conduction FM, rayonnement), signal | écart 0,1 K vs LIISignals (β=0), `mono.png` |
| `validate_vs_liisignals.py` | comparaison au code C++ | — |
| `lognormal.py` | bibliothèque T(t,d) sur 120 tailles résolue une fois, signal polydisperse = somme pondérée (~1 ms) | convergence 120 vs 240 tailles : 1e-10 ; `poly.png` montre la dégénérescence d32 |
| `grid_posterior.py` | bruit Sipkens 2017 `Var = (γ² + θ s + τ² s²)/N`, vraisemblance gaussienne, a posteriori sur grille 2D avec zoom auto | retrouve (20 nm, 1,3) ; corrélation −0,99 le long de d32 constant |

Résultats grille (d_pg=20 nm, σ_g=1,3) :
- N=100 tirs : d_pg 19,98±0,09 nm ; σ_g 1,300±0,003 ; d32 23,74±0,04 nm
- N=1 tir    : d_pg 19,1±0,9 nm ;  σ_g 1,32±0,03 ;   d32 23,3±0,4 nm

## 3. Hypothèses provisoires à lever
1. **Bruit** : γ=10, θ=1, τ=0,2, pic A=1000 comptes -> ordres de grandeur, à recaler sur Sipkens 2017
   (Appl. Opt. 56, 8436 ; code : github.com/tsipkens/pgm-error). PDF pas encore récupéré.
2. **Amplitude A supposée connue** -> trop optimiste. La rendre inconnue (3e paramètre).
3. **τ traité indépendant à chaque instant** alors qu'il multiplie toute la courbe d'un tir
   (largement absorbé si A est inconnue).
4. **Rayonnement corps noir (θ=1)** repris de LIISignals -> remplacer par l'émissivité Rayleigh
   (effet faible).
5. Paramètres = exemple LIISignals (1064 nm, 0,1 J/cm², Tg 1700 K, α 0,3, E(m) 0,4). Vérifier
   que la sublimation est bien négligeable, sinon baisser la fluence (ex. 0,05 J/cm²).
6. Ne pas utiliser le mode polydisperse de LIISignals comme référence (bug : sommes partielles).

## 4. Étapes suivantes
1. **MCMC (emcee)** sur (ln d_pg, ln σ_g, ln A), prior uniforme. Diagnostics : temps
   d'autocorrélation, R̂ (plusieurs chaînes), ESS. Comparer les marginales à la grille.
2. **Expériences jumelles** : 300–500 réalisations de bruit (plusieurs couples vrais), compter si la
   valeur vraie tombe dans les régions 68 % / 95 %. Tolérance ≈ ±2,5 pts pour 95 % sur 300 tirages.
   Tester aussi le cas « τ commun à toute la courbe » à la génération.
3. **Sensibilité α** : générer avec α_vrai, inverser avec α_supposé ∈ [0,2 ; 0,4] ; tracer le biais
   relatif sur d_pg et d32 vs α_supposé/α_vrai (attendu ≈ proportionnel).
4. **PINN (exploration)** :
   - PINN paramétrique T(τ; d, α) en variables adimensionnées, départ au pic, temps log,
     condition initiale imposée en dur -> substitut différentiable -> NUTS (numpyro) ;
     comparer la postérieure substitut vs exacte.
   - Option : PINN inverse (d entraînable) comme contre-exemple (pas d'incertitude).
   - Honnêteté : pour une EDO 1D, solve_ivp reste plus précis/rapide ; l'intérêt est la
     différentiabilité et l'amortissement.
5. **Rapport** : biblio, modèle + validation, bruit, grille vs MCMC, couverture, α, PINN.

## 5. Ordre de lecture
1. Michelsen 2015 (`liiArticle.pdf`) : intro + principes/bilan d'énergie.
2. Michelsen 2007 (`s00340-007-2619-5`) : équations du modèle, cas 0,05 J/cm² ; 10 modèles comparés.
3. Daun 2007 (`s00340-007-2585-y`) : mal-posé, vallée d32.
4. Sipkens 2022 (`s00340-022-07769-z`) : §2.3–2.4 (cadre bayésien).
5. Sipkens 2015 (`APB2015…RSG2.pdf`) : couplage α/d, annexe A (MCMC, marginalisation).
6. Sipkens 2019 (`s00340-019-7251-7`) : polydispersité, modèle simplifié (plus tard).
7. À récupérer : Sipkens 2017 (bruit), Hadwin 2018 (Kalman, réf. [4] du sujet).

## 6. Lancer
```
pip install numpy scipy matplotlib emcee
python lii_model.py        # mono.png
python lognormal.py        # poly.png
python grid_posterior.py   # posterior_grid.png (~1 min)
```
